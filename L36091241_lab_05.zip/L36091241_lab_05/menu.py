import pygame
import os

UPGRADEMENU_IMAGE = pygame.image.load(
    os.path.join('images', 'upgrade_menu.png'))
UPGRADE_IMAGE = pygame.transform.scale(pygame.image.load(
    os.path.join('images', 'upgrade.png')), (52, 20))
SELL_IMAGE = pygame.transform.scale(pygame.image.load(
    os.path.join('images', 'sell.png')), (40, 40))


class UpgradeMenu:
    def __init__(self, x, y):

        # load the menu image
        self.image = pygame.transform.scale(UPGRADEMENU_IMAGE, (200, 200))
        self.rect = self.image.get_rect()
        self.rect.center = [x, y]
        self.x = x
        self.y = y

        # load the buttons
        self.__buttons = [Button(UPGRADE_IMAGE, 'upgrade', self.x, self.y - 75),
                          Button(SELL_IMAGE, 'sell', self.x, self.y + 75)]  # (Q2) Add buttons here
        # self.rect.center = self.rect.topleft
        # Tower.rect.center

    def draw(self, win):
        """
        (Q1) draw menu itself and the buttons
        (This method is call in draw() method in class TowerGroup)
        :return: None
        """
        # draw menu
        win.blit(self.image, self.rect.topleft)

        # draw the button
        win.blit(UPGRADE_IMAGE, (self.x - 27, self.y - 80))
        win.blit(SELL_IMAGE, (self.x - 20, self.y + 55))

        # draw button
        # for botton in self.__buttons:
        #     win.blit(button, self.rect.center)
        # self.win.blit()
        # (Q2) Draw buttons here
        return None

    def get_buttons(self):
        """
        (Q1) Return the button list.
        (This method is call in get_click() method in class TowerGroup)
        :return: list
        """
        # return buttons list if get called
        return self.__buttons


class Button:
    def __init__(self, image, name, x, y):
        self.image = image
        self.name = name
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

    def clicked(self, x, y):
        """
        (Q2) Return Whether the button is clicked
        (This method is call in get_click() method in class TowerGroup)
        :param x: mouse x
        :param y: mouse y
        :return: bool
        """
        # if the botton is clicked, return True, checked by rect.collidepoint(),
        # gets called in TowerGroup.get_click().
        # mouse position is defined at game.py, class Game, then sent to class TowerGroup.
        # If not clicked, return False.

        return True if self.rect.collidepoint(x, y) else False

    def response(self):
        """
        (Q2) Return the button name.
        (This method is call in get_click() method in class TowerGroup)
        :return: str
        """
        # return the name
        return self.name
